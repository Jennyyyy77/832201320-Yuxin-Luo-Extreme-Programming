package cn.zwz.data.service;

import cn.zwz.data.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 用户 服务层接口
 * @author Yuxin Luo
 */
public interface IUserService extends IService<User> {

}
