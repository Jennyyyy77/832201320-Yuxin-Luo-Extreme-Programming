package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 系统日志 数据链路层接口
 * @author Yuxin Luo
 */
public interface LogMapper extends BaseMapper<Log> {
}
