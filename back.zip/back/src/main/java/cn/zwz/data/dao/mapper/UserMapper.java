package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 用户 数据链路层接口
 * @author Yuxin Luo
 */
public interface UserMapper extends BaseMapper<User> {
}
