package cn.zwz.data.service;

import cn.zwz.data.entity.Dict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 数据字典 服务层接口
 * @author Yuxin Luo
 */
public interface IDictService extends IService<Dict> {

}
