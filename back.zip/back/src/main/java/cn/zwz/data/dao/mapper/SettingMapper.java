package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Setting;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 设置 数据链路层接口
 * @author Yuxin Luo
 */
public interface SettingMapper extends BaseMapper<Setting> {
}
