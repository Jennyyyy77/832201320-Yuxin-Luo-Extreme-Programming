package cn.zwz.tel.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.tel.entity.CallRecord;

/**
 * 通话记录 服务层接口
 * @author Yuxin Luo
 */
public interface ICallRecordService extends IService<CallRecord> {

}