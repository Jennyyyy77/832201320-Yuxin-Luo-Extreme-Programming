package cn.zwz.test.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.test.entity.Student;

/**
 * 学生 服务层接口
 * @author Yuxin Luo
 */
public interface IStudentService extends IService<Student> {

}